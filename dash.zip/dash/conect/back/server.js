const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors());

const connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: 'jblackubuntu96$',
    database: 'meu_banco'
});

connection.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

app.get('/indicadores', (req, res) => {
    connection.query('SELECT * FROM indicadores', (error, results) => {
        if (error) {
            return res.status(500).send('Erro ao buscar dados');
        }
        res.json(results);
    });
});

const PORT = 8097;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
